"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ErrorMiddleware = void 0;
var ErrorMiddleware = /** @class */ (function () {
    function ErrorMiddleware() {
    }
    ErrorMiddleware.handle = function (err) {
        var statusCode = (err === null || err === void 0 ? void 0 : err.statusCode) || 500;
        return {
            statusCode: statusCode,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                httpCode: statusCode,
                internalCode: (err === null || err === void 0 ? void 0 : err.internalCode) || 'INTERNAL_SERVER_ERROR',
                message: err === null || err === void 0 ? void 0 : err.message,
            }),
        };
    };
    return ErrorMiddleware;
}());
exports.ErrorMiddleware = ErrorMiddleware;
