"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ResponseMiddleware = void 0;
var ResponseMiddleware = /** @class */ (function () {
    function ResponseMiddleware() {
    }
    ResponseMiddleware.handle = function (data, statusCode) {
        if (statusCode === void 0) { statusCode = 200; }
        return {
            statusCode: statusCode,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data),
        };
    };
    return ResponseMiddleware;
}());
exports.ResponseMiddleware = ResponseMiddleware;
