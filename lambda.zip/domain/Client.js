"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Client = void 0;
var CustomErrors_1 = require("./CustomErrors");
var Client = /** @class */ (function () {
    function Client(email, password) {
        this.email = email;
        this.password = password;
        if (!/^\S+@\S+\.\S+$/.test(email))
            throw new CustomErrors_1.ValidationError('E-mail inválido');
        if (password.length < 6)
            throw new CustomErrors_1.ValidationError('Senha inválida');
    }
    return Client;
}());
exports.Client = Client;
